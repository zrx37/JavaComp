
package PL2_clases;


public class ClientesException extends Exception {
    public static final String CLIENTE_REPETIDO = "El usuario ya existe";

    public ClientesException() {
        super("Se ha producido una excepción en la aplicación.");
    }
    
    public ClientesException(String txt) {
        super(txt);
    }
}
