
package PL2_clases;

/**
 *
 * @author UX425
 */
public class Probador {
    

    public static void main(String[] args) {
        // TODO code application logic here
        
    }
    
}
