/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PL2_clases;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author Alejandro
 */
public class GestionClientes {
    private static ArrayList<Cliente> clientes = new ArrayList<>();
    
    public GestionClientes() {
    }

    public static ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public static void setClientes(ArrayList<Cliente> clientes) {
        GestionClientes.clientes = clientes;
    }
    
    public static String registroClientes(Cliente cliente) {
        try {

            if (clientes.contains(cliente)) {
                throw new ClientesException(ClientesException.CLIENTE_REPETIDO);
            }
            clientes.add(cliente);
            return "Cliente registrado correctamente";
        } catch (ClientesException ce) {
            return ce.getMessage();
        }
    }
     public static List<Cliente> busquedaClientes(String correo, String clave) {

        List<Cliente> clientesBuscados = clientes.stream()
                .filter(cliente -> (cliente.getCorreo().equals(correo) && cliente.getClave().equals(clave)))
                        .sorted().collect(Collectors.toList());
        return clientesBuscados;
    }
}
