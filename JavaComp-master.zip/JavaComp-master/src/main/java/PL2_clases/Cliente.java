package PL2_clases;

import java.io.Serializable;
import java.time.LocalDate;



public class Cliente implements Serializable, Comparable<Cliente>{
    private String usuario;
    private String nombre;
    private int telefono;
    private int tarjetaCredito;   
    private String correo;
    private String clave;
    private String DNI;
    private String calle;
    private int numero;
    private int codigoPostal;
    private String ciudad;
    private LocalDate fecha;
    private String titular;

    public Cliente(String usuario, String nombre, int telefono, int tarjetaCredito, String correo, String clave, String DNI, String calle, int numero, int codigoPostal, String ciudad, LocalDate fecha, String titular) {
        this.usuario = usuario;
        this.nombre = nombre;
        this.telefono = telefono;
        this.tarjetaCredito = tarjetaCredito;
        this.correo = correo;
        this.clave = clave;
        this.DNI = DNI;
        this.calle = calle;
        this.numero = numero;
        this.codigoPostal = codigoPostal;
        this.ciudad = ciudad;
        this.fecha = fecha;
        this.titular = titular;
    }
   
    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public int getTarjetaCredito() {
        return tarjetaCredito;
    }

    public void setTarjetaCredito(int tarjetaCredito) {
        this.tarjetaCredito = tarjetaCredito;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(int codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }
    
    
    
    @Override
    public int compareTo(Cliente o) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

}    

   