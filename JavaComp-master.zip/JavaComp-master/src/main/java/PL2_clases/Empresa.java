
package PL2_clases;

import java.io.Serializable;
import java.time.LocalDate;


public class Empresa implements Serializable, Comparable<Empresa>{
    
    private String empresa;
    private String CIF;
    private String web;
    
    private int telefono;
    private int tarjetaCredito;
    private String titular;
    private String correo;
    private String clave;
    private String calle;
    private int numero;
    private int codigoPostal;
    private String ciudad;

    public Empresa(String empresa, String CIF, String web, String nombre, int telefono, int tarjetaCredito, String titular, LocalDate fecha, String correo, String clave, String calle, int numero, int codigoPostal, String ciudad) {
        this.empresa = empresa;
        this.CIF = CIF;
        this.web = web;
        this.telefono = telefono;
        this.tarjetaCredito = tarjetaCredito;
        this.titular = titular;
        this.correo = correo;
        this.clave = clave;
        this.calle = calle;
        this.numero = numero;
        this.codigoPostal = codigoPostal;
        this.ciudad = ciudad;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }
    public String getCIF() {
        return CIF;
    }

    public void setCIF(String CIF) {
        this.CIF = CIF;
    }

    public String getWeb() {
        return web;
    }

    public void setWeb(String web) {
        this.web = web;
    }
    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public int getTarjetaCredito() {
        return tarjetaCredito;
    }

    public void setTarjetaCredito(int tarjetaCredito) {
        this.tarjetaCredito = tarjetaCredito;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }
    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(int codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }
    
    


    @Override
    public int compareTo(Empresa o) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
