/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tienda;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
/**
 *
 * @author Alejandro
 */
public class UtilTienda {
    private static ArrayList<Producto> productos = new ArrayList<>();
    private static Producto objpro;
    
    public static void setProductos(ArrayList<Producto> p) {
        productos = p;
    }
    
    public static ArrayList<Producto> getProductos() {
        Comparator NomproComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Producto p1 = (Producto) o1;
                Producto p2 = (Producto) o2;
                return p1.getTitulo().compareTo(p2.getTitulo());
            }
        };
        Collections.sort(productos, NomproComp);
        return productos;
    }
    public static boolean RegistroProducto(Producto objpro) {
        if (consultaProductoPorTitulo(objpro.getTitulo()) == null) {
            productos.add(objpro);
            return true;
        } else {
            return false;
        }

    }
     public static boolean eliminarProducto(Producto objpro) {
        if (productos.contains(objpro)) {
            productos.remove(objpro);
            return true;
        } else {
            return false;
        }
    }
    public static Producto consultaProducto(int indice) {
        objpro = productos.get(indice);
        return objpro;
    }
    public static boolean modificaProducto(Producto pro, String p_titulo, double p_precio, String p_caracteristicas, LocalDate p_fecha, int p_stock, String p_categoria ) {
        if (pro == null || !productos.contains(pro)) {
            return false;
        }        
        pro.setTitulo(p_titulo);        
        pro.setPrecio(p_precio);
        pro.setStock(p_stock);
        pro.setCaracteristicas(p_caracteristicas);
        pro.setFechaEntrada(p_fecha);
        pro.setCategoria(p_categoria);
        
        return true;
    }
    
    public static boolean modificaProducto(Producto pro, String p_titulo, double p_precio) {
        if (pro == null || !productos.contains(pro)) {
            return false;
        }
        pro.setTitulo(p_titulo);
        pro.setPrecio(p_precio);
  
        
        return true;
    }
    public static Producto consultaProductoPorTitulo(String titulo) {
        Comparator TitproComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Producto p1 = (Producto) o1;
                Producto p2 = (Producto) o2;
                return p1.getTitulo().compareTo(p2.getTitulo());
            }
        };
        Collections.sort(productos, TitproComp);
        Producto p = new Producto();
        p.setTitulo(titulo);
        int pos = Collections.binarySearch(productos, p, TitproComp);
        if (pos >= 0) {
            objpro = productos.get(pos);
        } else {
            objpro = null;
        }

        return objpro;
    }
    public static void cargarDatos() {
        try {
            try (FileInputStream istreampro = new FileInputStream("copiasegpro.dat")) {
                ObjectInputStream oispro = new ObjectInputStream(istreampro);
                productos = (ArrayList) oispro.readObject();
            }
        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        } catch (ClassNotFoundException cnfe) {
            System.out.println("Error de clase no encontrada: " + cnfe.getMessage());
        } 
    }
     public static void guardarDatos() {
        try {
            //Si hay datos los guardamos...
            if (!productos.isEmpty()) {
                try (FileOutputStream ostreampro = new FileOutputStream("copiasegpro.dat")) {
                    ObjectOutputStream oospro = new ObjectOutputStream(ostreampro);
                    //guardamos el array de Productos
                    oospro.writeObject(productos);
                }
            } else {
                System.out.println("Error: No hay datos...");
            }

        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        } 
    }
    public static void generaFactura(Producto pro, int cantidad) throws IOException {
        LocalDate hoy = LocalDate.now();
        DateTimeFormatter formatoCorto = DateTimeFormatter.ofPattern("dd/MM/yyyy");        
        String fn = hoy.format(formatoCorto);        
        String rutaFicheroFactura = "./Facturas/Factura(" + fn.replace('/', '_') + ").txt";
        double importe = pro.getPrecio() * cantidad;
        try {
            //Si no existe el directorio Facturas, lo creamos
            File dirFacturas = new File("./Facturas");

            if (!dirFacturas.exists()) {
                dirFacturas.mkdir();
            }

            FileWriter fw = new FileWriter(rutaFicheroFactura);
            try (PrintWriter salida = new PrintWriter(new BufferedWriter(fw))) {
                salida.println("-------------------------------- Factura Producto --------------------------------");
                salida.println("\n");
                salida.println("-------------------------------- Fecha: " + fn + " -------------------------------");
                salida.println("\n");
                salida.println("Categoria: " + pro.getCategoria());
                salida.println("\n");
                salida.println("Tipo: Teléfono Móvil");
                salida.println("Nombre: " + pro.getTitulo());
                salida.println("\n");
                salida.println("Precio: " + pro.getPrecio());
                salida.println("Cantidad: " + cantidad);
                salida.println("---------------------------------------------------------------------------------");
                salida.println("IMPORTE: " + importe);
                salida.println("\n");
                salida.println("-------------------------------------------------------------------------------");
            }
        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        }
    }

   
}


