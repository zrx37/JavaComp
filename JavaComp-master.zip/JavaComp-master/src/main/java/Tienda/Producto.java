
package Tienda;

import java.time.LocalDate;
import java.io.Serializable;
import java.util.Objects;
import javax.swing.JComboBox;

public class Producto implements Serializable{

    private String titulo;
    private String caracteristicas;
    private String categoria;
    private double precio;
    private int fechaEntrada;
    private long stock;
    private String opinion;

    public Producto(String titulo, String caracteristicas, String categoria, double precio, int fechaEntrada, long stock) {
        this.titulo = titulo;
        this.caracteristicas = caracteristicas;
        this.categoria = categoria;
        this.precio = precio;
        this.fechaEntrada = fechaEntrada;
        this.stock = stock;
        
    }

    Producto() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    
    public String getCaracteristicas() {
        return caracteristicas;
    }

    public void setCaracteristicas(String caracteristicas) {
        this.caracteristicas = caracteristicas;
    }
    
    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getFechaEntrada() {
        return fechaEntrada;
    }

    public void setFechaEntrada(int fechaEntrada) {
        this.fechaEntrada = fechaEntrada;
    }

    public long getStock() {
        return stock;
    }

    public void setStock(long stock) {
        this.stock = stock;
    }

    
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 23 * hash + Objects.hashCode(this.categoria);
        return hash;
    }
    @Override
    
        public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Producto other = (Producto) obj;
        if (!Objects.equals(this.categoria, other.categoria)) {
            return false;
        }
        return true;
    
        }
    @Override
    public String toString() {
        return "Producto{" + " - categoria= " + categoria + " - titulo = " + titulo + " - caracteristicas = " + caracteristicas + " - precio = " + precio + " - stock = " + stock + " - fecha de entrada = " + fechaEntrada + " - opinió = " + opinion +'}';
    }
  
}
