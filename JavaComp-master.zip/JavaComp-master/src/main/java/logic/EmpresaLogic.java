/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logic;

/**
 *
 * @author Víctor Zurita
 */
import PL2_clases.Empresa;
import modelo.dao.EmpresaDAO;

public class EmpresaLogic {
    private static EmpresaDAO empresaDAO = new EmpresaDAO();

    public static boolean autentificar(String empresa, String clave){
        if (obtener(empresa) != null){
            Empresa empresaConsulta=obtener(empresa);
            return empresaConsulta.getEmpresa().equals(empresa)&&empresaConsulta.getClave().equals(clave);
        }else{
            return false;
        }
    }

    public static boolean insertar(Empresa empresa){
       return empresaDAO.insertar(empresa);
    }

    public static boolean modificar(Empresa empresa){
        return empresaDAO.modificar(empresa);
    }

    public static boolean eliminar(String empresa){
       return empresaDAO.eliminar(empresa);
    }

    public static Empresa obtener (String cliente){
       return empresaDAO.obtener(cliente);
    }

}

