# JavaComp

Versión 1.0:

Se han creado las clases y ventanas sin rellenar, las clases tienen todos sus constructores correspondientes.

Versión 1.1:

Se han creado las primeras ventanas.

Versión 1.2:

se empieza a trabajar con el arraylist.

Versión 1.3

se mejora la interfaz.
