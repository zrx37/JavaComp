package Logica;

import java.util.*;
import java.util.stream.Collectors;

public class GestionUsuarios {

    private static ArrayList<Usuario> usuarios = new ArrayList<>();

    public GestionUsuarios() {
    }

    public static ArrayList<Usuario> getUsuarios() {
        return usuarios;
    }

    public static void setUsuarios(ArrayList<Usuario> usuarios) {
        GestionUsuarios.usuarios = usuarios;
    }

    //método para añadir usuarios
    public static String altaUsuarios(Usuario usuario) {
        try {

            if (usuarios.contains(usuario)) {
                throw new UsuariosException(UsuariosException.USUARIO_REPETIDO);
            }
            usuarios.add(usuario);
            return "Usuario dado de alta correctamente";
        } catch (UsuariosException ue) {
            return ue.getMessage();
        }
    }

    //método búsqueda de usuarios que devuelve una lista con los usuarios encontrados
    public static List<Usuario> busquedaUsuarios(String nombre, String correo) {

        List<Usuario> usuariosBuscados = usuarios.stream()
                .filter(u -> (u.getNombre().equals(nombre) && u.getCorreo().equals(correo)))
                        .sorted().collect(Collectors.toList());
        /* Sin streams:
        ArrayList<OfertaEmpleo> ofertasBuscadas = new ArrayList<>();
        for (OfertaEmpleo oe : ofertas) {
                if (oe.getCategoria().equals(categoria) && oe.getSalario() >= salario) {
                    ofertasBuscadas.add(oe);
                }
        }
        return ofertasBuscadas;
        */

        return usuariosBuscados;
    }
}
