/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

import Logica.Usuario;
import Logica.Usuario;
import Logica.UsuarioDao;
/**
 *
 * @author Alejandro
 */
public class UsuarioLogic {
    private static UsuarioDao usuariodao = new UsuarioDao();
    
    public static boolean autentificar(String correo, String clave){
        if (obtener(correo) != null){
            Usuario usuarioConsulta=obtener(correo);
            if (usuarioConsulta.getCorreo().equals(correo)&&usuarioConsulta.getClave().equals(clave)) {
                return true;
            }
            else{
                return false;
        }
        }else{
            return false;
        }
    }
    
     public static Usuario obtener (String correo){
       return usuariodao.obtener(correo);        
    }
}
