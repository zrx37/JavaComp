package Logica;

import java.util.*;
import java.util.stream.Collectors;

public class GProductos {

    private static ArrayList<Producto> productos = new ArrayList<>();

    public GProductos() {
    }

    public static ArrayList<Producto> getProductos() {
        return productos;
    }

    public static void setProductos(ArrayList<Producto> productos) {
        GProductos.productos = productos;
    }



    //método búsqueda de usuarios que devuelve una lista con los usuarios encontrados
    public static List<Producto> busquedaProductos(String titulo, String categoria) {

        List<Producto> productosBuscados = productos.stream()
                .filter(u -> (u.getTitulo().equals(titulo) && u.getCategoria().equals(categoria)))
                        .sorted().collect(Collectors.toList());
        /* Sin streams:
        ArrayList<OfertaEmpleo> ofertasBuscadas = new ArrayList<>();
        for (OfertaEmpleo oe : ofertas) {
                if (oe.getCategoria().equals(categoria) && oe.getSalario() >= salario) {
                    ofertasBuscadas.add(oe);
                }
        }
        return ofertasBuscadas;
        */

        return productosBuscados;
    }
}
