package Logica;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class UtilTienda {

    private static ArrayList<Producto> productos = new ArrayList<>();
    private static Producto objpro;

    /** Establece el ArrayList de Productos
     * @param p */
    public static void setProductos(ArrayList<Producto> p) {
        productos = p;
    }

    /** Devuelve el ArrayList de Productos
     * @return  */
    public static ArrayList<Producto> getProductos() {
        //Comparador para ordenar los Productos por su nombre
        Comparator NomproComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Producto p1 = (Producto) o1;
                Producto p2 = (Producto) o2;
                return p1.getTitulo().compareTo(p2.getTitulo());
            }
        };
        //Ordenamos el array
        Collections.sort(productos, NomproComp);
        return productos;
    }

    /** Da de alta una Producto
     * @param objpro
     * @return  */
    public static boolean altaProducto(Producto objpro) {
        if (consultaProductoPorTitulo(objpro.getTitulo()) == null) {
            productos.add(objpro);
            return true;
        } else {
            return false;
        }

    }

    /** Da de baja una Producto
     * @param objpro
     * @return  */
    public static boolean bajaProducto(Producto objpro) {
        if (productos.contains(objpro)) {
            productos.remove(objpro);
            return true;
        } else {
            return false;
        }
    }

    /** Devuelve un Producto por la posición dentro del ArrayList
     * @param indice
     * @return  */
    public static Producto consultaProducto(int indice) {
        objpro = productos.get(indice);
        return objpro;
    }

    /** Modifica los datos de un Producto
     * @param pro     
     * @param p_titulo
     * @param p_caracteristicas
     * @param p_categoria
     * @param p_precio
     * @param p_stock
     * @return  */
    public static boolean modificaProducto(Producto pro, String p_titulo, String p_caracteristicas, String p_categoria, double p_precio, int p_stock) {
        if (pro == null || !productos.contains(pro)) {
            return false;
        }        
        pro.setTitulo(p_titulo);  
        pro.setCaracteristicas(p_caracteristicas);
        pro.setCategoria(p_categoria);
        pro.setPrecio(p_precio);
        pro.setStock(p_stock);
        return true;
    }

    /** Modifica los datos de un Producto
     * @param pro
     * @param p_titulo
     * @param p_precio
     * @return  */
    public static boolean modificaProducto(Producto pro, String p_titulo, double p_precio) {
        if (pro == null || !productos.contains(pro)) {
            return false;
        }
        pro.setTitulo(p_titulo);
        pro.setPrecio(p_precio);
        return true;
    }

    /** Consulta los datos de un Producto por su título
     * @param titulo
     * @return  */
    public static Producto consultaProductoPorTitulo(String titulo) {
        //Comparador para ordenar los Productos por su título
        Comparator TituloproComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Producto p1 = (Producto) o1;
                Producto p2 = (Producto) o2;
                return p1.getTitulo().compareTo(p2.getTitulo());
            }
        };
        //Ordenamos el array
        Collections.sort(productos, TituloproComp);
        //creamos un Producto con el titulo a buscar
        Producto p = new Producto();
        p.setTitulo(titulo);
        int pos = Collections.binarySearch(productos, p, TituloproComp);
        if (pos >= 0) {
            objpro = productos.get(pos);
        } else {
            objpro = null;
        }

        return objpro;
    }

    /** Consulta los datos de un Producto por su Características
     * @param caracteristicas
     * @return  */
    public static Producto consultaProductoPorCaracteristicas(String caracteristicas) {
        //Comparador para ordenar las Productos por sus características
        Comparator NomproComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Producto p1 = (Producto) o1;
                Producto p2 = (Producto) o2;
                return p1.getCaracteristicas().compareTo(p2.getCaracteristicas());
            }
        };
        //Ordenamos el array
        Collections.sort(productos, NomproComp);
        //creamos una Producto con el nombre a buscar
        Producto p = new Producto();
        p.setCaracteristicas(caracteristicas);
        int pos = Collections.binarySearch(productos, p, NomproComp);
        if (pos >= 0) {
            objpro = productos.get(pos);
        } else {
            objpro = null;
        }

        return objpro;
    }

    /** Carga los datos de Productos del fichero */
    public static void cargarDatos() {
        try {
            try (FileInputStream istreampro = new FileInputStream("copiasegpro.dat")) {
                ObjectInputStream oispro = new ObjectInputStream(istreampro);
                productos = (ArrayList) oispro.readObject();
            }
        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        } catch (ClassNotFoundException cnfe) {
            System.out.println("Error de clase no encontrada: " + cnfe.getMessage());
        } 
    }//fin cargarDatos

    /** Guarda los datos de Productos en el fichero */
    public static void guardarDatos() {
        try {
            //Si hay datos los guardamos...
            if (!productos.isEmpty()) {
                try (FileOutputStream ostreampro = new FileOutputStream("copiasegpro.dat")) {
                    ObjectOutputStream oospro = new ObjectOutputStream(ostreampro);
                    //guardamos el array de Productos
                    oospro.writeObject(productos);
                }
            } else {
                System.out.println("Error: No hay datos...");
            }

        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        } 
    }//fin guardarDatos

    /** Crea un fichero de texto con los datos de una venta
     * @param pro
     * @param cantidad
     * @throws java.io.IOException */
    public static void generaFactura(Producto pro, int cantidad) throws IOException {
        LocalDate hoy = LocalDate.now();
        DateTimeFormatter formatoCorto = DateTimeFormatter.ofPattern("dd/MM/yyyy");        
        String fn = hoy.format(formatoCorto);        
        String rutaFicheroFactura = "./Facturas/Factura(" + fn.replace('/', '_') + ").txt";
        double importe = pro.getPrecio() * cantidad;
        try {
            //Si no existe el directorio Facturas, lo creamos
            File dirFacturas = new File("./Facturas");

            if (!dirFacturas.exists()) {
                dirFacturas.mkdir();
            }

            FileWriter fw = new FileWriter(rutaFicheroFactura);
            try (PrintWriter salida = new PrintWriter(new BufferedWriter(fw))) {
                salida.println("-------------------------------- Factura Producto --------------------------------");
                salida.println("\n");
                salida.println("-------------------------------- Fecha: " + fn + " -------------------------------");
                salida.println("\n");
                salida.println("Título: " + pro.getTitulo());
                salida.println("\n");
            
                    salida.println("Tipo: Teléfono Móvil");
                    salida.println("Características: " + pro.getCaracteristicas());
                    salida.println("Categoría: " + pro.getCategoria());
                
                salida.println("\n");
                salida.println("Precio: " + pro.getPrecio());
                salida.println("Cantidad: " + cantidad);
                salida.println("---------------------------------------------------------------------------------");
                salida.println("IMPORTE: " + importe);
                salida.println("\n");
                salida.println("-------------------------------------------------------------------------------");
            }
        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        }
    }//fin generaFactura

}
