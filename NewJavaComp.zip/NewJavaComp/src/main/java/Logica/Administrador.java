
package Logica;

public class Administrador{
        private String Administrador;
        private String Clave;
        
        
	public Administrador() {
		
	}
    public Administrador(String Administrador, String Clave) {
        this.Administrador = Administrador;
        this.Clave = Clave;
    }

    public String getAdministrador() {
        return Administrador;
    }

    public void setAdministrador(String Administrador) {
        this.Administrador = Administrador;
    }

    public String getClave() {
        return Clave;
    }

    public void setClave(String Clave) {
        this.Clave = Clave;
    }     
        
    }
    
   
