/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Logica;

import java.util.ArrayList;
import java.util.List;
import Logica.Usuario;
import Logica.Usuario;
/**
 *
 * @author Alejandro
 */
public class UsuarioDao {
    private List<Usuario> usuarios;
    
    public UsuarioDao(){
    usuarios = new ArrayList<>();
    }
     public int buscar(String correo){
        int n=-1;
        for (int i = 0; i < usuarios.size(); i++){
            if (usuarios.get(i).getCorreo().equals(correo)) {
                n=i;
                break;
            }
        }
        return n; 
    }
     
    public Usuario obtener(String correo){
        if (buscar(correo) != -1) {
            return usuarios.get(buscar(correo));
        }else {
            return null;
        }
    }
}
