package Logica;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class UtilRegistro {

    private static ArrayList<Usuario> usuarios = new ArrayList<>();
    private static Usuario objus;

    /** Establece el ArrayList de Productos
     * @param u */
    public static void setUsuarios(ArrayList<Usuario> u) {
        usuarios = u;
    }

    /** Devuelve el ArrayList de Usuarios
     * @return  */
    public static ArrayList<Usuario> getUsuarios() {
        //Comparador para ordenar los Usuarios por su nombre
        Comparator NomusComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Usuario u1 = (Usuario) o1;
                Usuario u2 = (Usuario) o2;
                return u1.getNombre().compareTo(u2.getNombre());
            }
        };
        //Ordenamos el array
        Collections.sort(usuarios, NomusComp);
        return usuarios;
    }

    /** Da de alta una Producto
     * @param objpro
     * @return  */
    public static boolean altaUsuario(Usuario objus) {
        if (consultaUsuarioPorCorreo(objus.getCorreo()) == null) {
            usuarios.add(objus);
            return true;
        } else {
            return false;
        }

    }

    /** Da de baja una Producto
     * @param objus
     * @return  */
    public static boolean bajaUsuario(Usuario objus) {
        if (usuarios.contains(objus)) {
            usuarios.remove(objus);
            return true;
        } else {
            return false;
        }
    }

    /** Devuelve un Producto por la posición dentro del ArrayList
     * @param indice
     * @return  */
    public static Usuario consultaUsuario(int indice) {
        objus = usuarios.get(indice);
        return objus;
    }

    /** Modifica los datos de un Usuario
     * @param us     
     * @param u_nombre
     * @param u_correo
     * @param u_clave
     * @param u_calle
     * @param u_numero
     * @param u_codigoPostal
     * @param u_ciudad
     * @param u_tarjeta
     * @param u_titular
     * @param u_telefono
     * @param var
     * @return  */
    public static boolean modificaUsuario(Usuario us, String u_nombre, String u_correo, String u_clave, String u_calle, int u_numero, int u_codigoPostal, String u_ciudad, int u_tarjeta, String u_titular, int u_telefono, String var) {
        if (us == null || !usuarios.contains(us)) {
            return false;
        }        
        us.setNombre(u_nombre);        
        us.setCorreo(u_correo);
        us.setClave(u_clave);
        us.setCalle(u_calle);
        us.setNumero(u_numero);
        us.setCodigoPostal(u_codigoPostal);
        us.setCiudad(u_ciudad);
        us.setTarjeta(u_tarjeta);
        us.setTitular(u_titular);
        us.setTelefono(u_telefono);
        String tipo = us.getClass().getSimpleName();
        if (tipo.equals("Cliente")) {
            Cliente cli = (Cliente) us;
            cli.setDni(var);

        } else {
            Empresa emp = (Empresa) us;
            emp.setCif(var);
            emp.setWeb(var);
        }
        return true;
    }

    /** Modifica los datos de un Usuario
     * @param us
     * @param u_nombre
     * @param u_correo
     * @param var
     * @return  */
    public static boolean modificaUsuario(Usuario us, String u_nombre, String u_correo, String var) {
        if (us == null || !usuarios.contains(us)) {
            return false;
        }
        us.setNombre(u_nombre);
        us.setCorreo(u_correo);
        String tipo = us.getClass().getSimpleName();
        if (tipo.equals("Cliente")) {
            Cliente cli = (Cliente) us;
            cli.setDni(var);

        } else {
            Empresa emp = (Empresa) us;
            emp.setCif(var);
            emp.setWeb(var);
        }
        return true;
    }

    /** Consulta los datos de un Usuario por su correo
     * @param correo
     * @return  */
    public static Usuario consultaUsuarioPorCorreo(String correo) {
        //Comparador para ordenar los Usuarios por su correo
        Comparator CorreousComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Usuario u1 = (Usuario) o1;
                Usuario u2 = (Usuario) o2;
                return u1.getCorreo().compareTo(u2.getCorreo());
            }
        };
        //Ordenamos el array
        Collections.sort(usuarios, CorreousComp);
        //creamos un Usuario con el correo a buscar
        Usuario u = new Usuario();
        u.setCorreo(correo);
        int pos = Collections.binarySearch(usuarios, u, CorreousComp);
        if (pos >= 0) {
            objus = usuarios.get(pos);
        } else {
            objus = null;
        }

        return objus;
    }

    /** Consulta los datos de un Usuario por su nombre
     * @param nombre
     * @return  */
    public static Usuario consultaUsuarioPorNombre(String nombre) {
        //Comparador para ordenar las Productos por su nombre
        Comparator NomusComp = new Comparator() {

            @Override
            public int compare(Object o1, Object o2) {
                Usuario u1 = (Usuario) o1;
                Usuario u2 = (Usuario) o2;
                return u1.getNombre().compareTo(u2.getNombre());
            }
        };
        //Ordenamos el array
        Collections.sort(usuarios, NomusComp);
        //creamos un Usuario con el nombre a buscar
        Usuario u = new Usuario();
        u.setNombre(nombre);
        int pos = Collections.binarySearch(usuarios, u, NomusComp);
        if (pos >= 0) {
            objus = usuarios.get(pos);
        } else {
            objus = null;
        }

        return objus;
    }

    /** Carga los datos de Usuarios del fichero */
    public static void cargarDatos() {
        try {
            try (FileInputStream istreamus = new FileInputStream("copiasegus.dat")) {
                ObjectInputStream oisus = new ObjectInputStream(istreamus);
                usuarios = (ArrayList) oisus.readObject();
            }
        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        } catch (ClassNotFoundException cnfe) {
            System.out.println("Error de clase no encontrada: " + cnfe.getMessage());
        } 
    }//fin cargarDatos

    /** Guarda los datos de Usuarios en el fichero */
    public static void guardarDatos() {
        try {
            //Si hay datos los guardamos...
            if (!usuarios.isEmpty()) {
                try (FileOutputStream ostreamus = new FileOutputStream("copiasegus.dat")) {
                    ObjectOutputStream oosus = new ObjectOutputStream(ostreamus);
                    //guardamos el array de Usuarios
                    oosus.writeObject(usuarios);
                }
            } else {
                System.out.println("Error: No hay datos...");
            }

        } catch (IOException ioe) {
            System.out.println("Error de IO: " + ioe.getMessage());
        } 
    }//fin guardarDatos



    public static boolean modificaUsruaro(Usuario objus, String nombre, String correo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
