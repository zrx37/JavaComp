package Logica;

import java.io.Serializable;
import java.util.Objects;

public class Usuario implements Serializable {

    private String nombre;
    private String correo;
    private String clave;
    private String calle;
    private int numero;
    private int codigoPostal;
    private String ciudad;
    private int tarjeta;
    private String titular;
    private int telefono;

    public Usuario() {
    }

    public Usuario(String nombre, String correo, String clave, String calle, int numero, int codigoPostal, String ciudad, int tarjeta, String titular, int telefono) {
        this.nombre = nombre;
        this.correo = correo;
        this.clave = clave;
        this.calle = calle;
        this.numero = numero;
        this.codigoPostal = codigoPostal;
        this.ciudad = ciudad;
        this.tarjeta = tarjeta;
        this.titular = titular;
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public int getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(int codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public int getTarjeta() {
        return tarjeta;
    }

    public void setTarjeta(int tarjeta) {
        this.tarjeta = tarjeta;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    
        
    @Override
    public String toString() {
        return "Usuario{" + " - nombre = " + nombre + " - correo = " + correo + " - clave = " + clave + " - calle = " + calle + " - numero = " + numero + " - codigo postal = " + codigoPostal + " - ciudad = " + ciudad + " - numero de tarjeta = " + tarjeta + " - nombre del titular = " + titular + " - telefono = " + telefono + '}';
    }
}
