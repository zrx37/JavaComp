package Logica;

public class Cliente extends Usuario{
    private String dni;

    public Cliente(String nombre, String correo, String clave, String calle, int numero, int codigoPostal, String ciudad, int tarjeta, String titular, int telefono, String dni) {
        super(nombre, correo, clave, calle, numero, codigoPostal, ciudad, tarjeta, titular, telefono);
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    @Override
    public String toString() {
        return super.toString() + "\nCliente{" + " - DNI = " + dni + '}';
    }

   
}
