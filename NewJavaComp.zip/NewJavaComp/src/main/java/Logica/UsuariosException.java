package Logica;

public class UsuariosException extends Exception {

    public static final String USUARIO_REPETIDO = "El usuario ya existe";

    public UsuariosException() {
        super("Se ha producido una excepción en la aplicación.");
    }

    public UsuariosException(String txt) {
        super(txt);
    }
}
