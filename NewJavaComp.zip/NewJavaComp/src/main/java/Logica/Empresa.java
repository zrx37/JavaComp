package Logica;

public class Empresa extends Usuario{
    private String cif;
    private String web;

    public Empresa(String nombre, String correo, String clave, String calle, int numero, int codigoPostal, String ciudad, int tarjeta, String titular, int telefono, String cif, String web) {
        super(nombre, correo, clave, calle, numero, codigoPostal, ciudad, tarjeta, titular, telefono);
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getWeb() {
        return web;
    }

    public void setWeb(String web) {
        this.web = web;
    }

    

    @Override
    public String toString() {
        return super.toString() + "\nEmpresa{" + " - CIF = " + cif + " - web = " + web +'}';
    }

}
