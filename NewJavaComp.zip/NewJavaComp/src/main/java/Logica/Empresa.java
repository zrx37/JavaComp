package Logica;

public class Empresa extends Usuario{
    private String cif;

    public Empresa(String nombre, String correo, String clave, String calle, int numero, int codigoPostal, String ciudad, int tarjeta, String titular, int telefono, String cif) {
        super(nombre, correo, clave, calle, numero, codigoPostal, ciudad, tarjeta, titular, telefono);
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }



    

    @Override
    public String toString() {
        return super.toString() + "\nEmpresa{" + " - CIF = " + cif + '}';
    }

}
